import unittest
from si import simple_interest, total_amount

class TestSimpleInterest(unittest.TestCase):
    def test_basic(self):
        self.assertAlmostEqual(simple_interest(10000, 12, 1.5), 1800.0)
        self.assertAlmostEqual(total_amount(10000, 12, 1.5), 11800.0)

    def test_zero(self):
        self.assertEqual(simple_interest(0, 10, 5), 0.0)
        self.assertEqual(simple_interest(1000, 0, 5), 0.0)
        self.assertEqual(simple_interest(1000, 10, 0), 0.0)

    def test_validation(self):
        with self.assertRaises(ValueError):
            simple_interest(-1, 10, 1)
        with self.assertRaises(ValueError):
            simple_interest(100, 10, -1)

if __name__ == '__main__':
    unittest.main()
